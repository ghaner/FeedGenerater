# sources.json 配置 Schema（FeedGitHubGenerater）

`sources.json` 是整个项目的**唯一配置入口**。新增一个网址 = 在 `sources` 数组加一条，
无需改代码。生成器（`scripts/generate_feed.py`）遍历它，为每个启用源产出 `<name>.xml`。

---

## 顶层字段

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `ua` | string | 否 | 全局 User-Agent；默认 `"Mozilla/5.0"`。建议填完整 Chrome UA 以降被拦概率。 |
| `timeout` | int | 否 | 抓取超时秒数；默认 `40`。 |
| `sources` | array | 是 | 源配置数组，每个元素一个 RSS 源。 |

---

## 单个源的字段

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `name` | string | 是 | 文件名前缀，生成的将是 `<name>.xml`。**只能字母数字下划线，避免特殊字符**。 |
| `parser` | string | 是 | 解析器：`generic`（正则配置驱动）或 `seedog`（seedog.cc 专用）。新增专用站点需在生成器 `PARSERS` 注册。 |
| `url` | string | 是 | 目标「按更新排序的列表页」地址。 |
| `base` | string | 是 | 站点根域名，用于把相对链接补成绝对地址（字段 `abs:true` 时）。 |
| `feed_title` | string | 是 | RSS `<channel><title>`，阅读器订阅时显示的名称。 |
| `feed_desc` | string | 否 | RSS 描述。 |
| `ttl` | int | 否 | RSS `<ttl>`（分钟），默认 `60`。 |
| `template` | string | 否 | 每条 `<description>` 的 HTML 卡片，`{字段名}` 会被替换为提取结果；默认 `<div>{title}<br>{link}</div>`。 |
| `enabled` | bool | 否 | `false` 时跳过该源、不出文件。暂停某源用，不影响其他源。 |
| `note` | string | 否 | 备注，仅给人看。 |
| `fetch` | string | 否 | 抓取方式：`http`（默认，urllib 直连）或 `browser`（Playwright 过 JS 挑战）。 |
| `limit` | int | 否 | 只保留前 N 条（首页常混入推荐/专题位）。 |
| `wait_selector` | string | 否 | `fetch:"browser"` 时，挑战解除后再等该 CSS 选择器出现（SPA 等渲染）。 |
| `settle` | int | 否 | `fetch:"browser"` 时，额外稳定等待秒数；默认 `5`。 |
| `max_wait` | int | 否 | `fetch:"browser"` 时，轮询等待挑战解除的最长秒数；默认 `40`。 |
| `item_block` | string | 是* | `parser:"generic"` 必填。一个捕获组 = 一个条目块的正则。 |
| `fields` | object | 是* | `parser:"generic"` 必填。各字段的正则定义。 |

\* `parser:"generic"` 必须有 `item_block` 与 `fields`；`parser:"seedog"` 不需要（逻辑写死在解析器内）。

---

## `fields` 子字段定义

每个字段是一个对象，键是要提取的字段名（会注入 `template`）：

| 子字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `pattern` | string | 是 | 提取该字段的正则（在条目块内 `re.search`）。 |
| `group` | int | 否 | 取第几个捕获组；默认 `1`。 |
| `strip_tags` | bool | 否 | `true` 去掉 HTML 标签，返回纯文本。 |
| `abs` | bool | 否 | `true` 把相对链接用 `base` 补成绝对地址（链接/图片必开）。 |
| `i` | bool | 否 | `true` 忽略大小写。 |

---

## 完整示例（generic 解析一个影视列表页）

```json
{
  "name": "mysite",
  "parser": "generic",
  "url": "https://example.com/?order=new",
  "base": "https://example.com",
  "feed_title": "我的站点 最近更新",
  "feed_desc": "……",
  "ttl": 60,
  "item_block": "<div class=\"vod\">(.*?)</div>",
  "fields": {
    "poster": {"pattern": "<img src=\"([^\"]+)\"", "group": 1, "abs": true},
    "link":   {"pattern": "href=\"([^\"]+)\"", "group": 1, "abs": true},
    "title":  {"pattern": "<h3>(.*?)</h3>", "group": 1, "strip_tags": true},
    "meta":   {"pattern": "<span>(.*?)</span>", "group": 1, "strip_tags": true}
  },
  "template": "<div><a href=\"{link}\"><img src=\"{poster}\"></a><b>{title}</b><p>{meta}</p></div>"
}
```

要点：
- `{字段名}` 在 `template` 中按名字替换；未提取到的字段为空字符串。
- `abs:true` 解决「详情/图片是 `/movies/123/` 这种相对路径」的问题。
- 站点改版（条目标签变化）会使提取失效：脚本因此跳过该源、保留旧 feed，需同步更新对应正则。

---

## 多源共存示例（sources 数组）

```json
{
  "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ... Chrome/120.0.0.0 Safari/537.36",
  "timeout": 40,
  "sources": [
    { "name": "seedog", "parser": "seedog", "url": "https://seedog.cc/?order=update", "base": "https://seedog.cc", "feed_title": "SeedHub 最近更新", "ttl": 60, "template": "..." },
    { "name": "mysite", "parser": "generic", "url": "...", "base": "...", "item_block": "...", "fields": {...}, "template": "..." }
  ]
}
```

每个源相互独立：一个被反爬拦截，其它源照常出文件，订阅互不影响。
