# 部署与排错指南（FeedGitHubGenerater）

本 skill 的产物是一个「GitHub 仓库 + GitHub Pages + GitHub Actions」的 RSS 生成器。
下面是从零上线到稳定运行的关键步骤，以及实战踩坑（均来自真实站点 seedog.cc / kkys14.com）。

---

## 一、项目目录结构（脚手架）

```
<仓库名>/
├── .github/workflows/generate.yml   # 定时重新生成所有 *.xml 并推送
├── src/
│   ├── generate_feed.py             # 主程序（复制 skill 的 scripts/generate_feed.py）
│   └── sources.json                 # ★ 站点配置：新增网址只改这里
├── <name>.xml                       # 生成的 RSS（每个源一个文件）
├── preview.bat                      # 本机一键生成并打开所有 *.xml（备用预览）
├── publish.bat                      # 本机生成 + git 提交 + 推送（备用刷新）
├── .gitignore
└── README.md
```

- `generate_feed.py` 约定放在 `src/`，同目录找 `sources.json`，产物写到仓库根目录。
- `.gitignore` 至少排除 `.workbuddy/`（本地记忆）、`__pycache__/`、`test/*.html`、`test/*.txt`。

---

## 二、让阅读器拿到 URL（两步）

### 步骤 1：开启 GitHub Pages
1. 仓库 **Settings → Pages**。
2. **Build and deployment → Source** 选 **Deploy from a branch**；**Branch** 选 `main`，目录 **`/ (root)`**，保存。
3. 一两分钟后访问 `https://<用户>.github.io/<仓库>/<name>.xml` 应见到 RSS XML。
4. 把这个 URL 填进 Distill Web Monitor 的 **Feed → GET**、或 Feedly / Fluent Reader 订阅。

> 每个源对应一个文件：`https://<用户>.github.io/<仓库>/<name>.xml`（name 见 sources.json）。

### 步骤 2：保持更新（GitHub Actions 自动完成）
- `generate.yml` 每日零点（北京时间，即 UTC 16:00）自动遍历所有启用源 → 抓取 → 重新生成各自 `*.xml` → 校验 → 提交推送。
- 若某次被反爬拦截（命中挑战页或提取 0 条），脚本**不覆盖**该 feed，保留上一次成功结果，订阅不中断。
- 周期在 `cron: "0 16 * * *"`（标准 cron，**UTC**）调整；想改回 UTC 零点写 `0 0 * * *`。
- 可在 **Actions → Generate RSS Feeds → Run workflow** 手动立即刷新。

---

## 三、反爬实战排错（来自真实站点）

### 现象 A：抓到的全是 `Just a moment...` / `challenges.cloudflare.com`
**根因**：站点前有 Cloudflare，挑战按「IP 信誉」判定。数据中心 IP（含多数代理/服务器 IP）会被直接判为机器人。

**对策（按优先级）**：
1. **用本机 IP 直连**：很多个人宽带 IP 被 Cloudflare 信任，urllib 直连（fetch 默认 `http`）即可过。
2. **关掉代理**：代理走数据中心 IP，信誉比直连更差，勾代理必败。
3. **带 `cf_clearance` Cookie 兜底**：用真实 Chrome 打开站点通过验证 → F12 → Application → Cookies → 复制 Name 为 `cf_clearance` 的 Value（注意不是 `XLA_CI`、`__cf_bm`）→ 在 fetch 请求里加 `-b "cf_clearance=..."`。有效期约 30 分钟～数小时，绑定域名+指纹+IP。
4. **换 `fetch:"browser"`**：Playwright 无头浏览器跑 JS 过挑战（见现象 B）。

### 现象 B：SPA 站点（如 kkys14.com）拿到空壳（0 条）
**根因**：静态 HTML 只是空壳，影片列表由 JS 异步渲染；`urllib` 直连只拿到挑战页或骨架。

**对策**：
- 配置 `fetch:"browser"`（Playwright 跑 JS 过 cdndefend / Cloudflare 算力挑战，并等待 SPA 渲染完再取 HTML）。
- CI 需先装：`pip install playwright && python -m playwright install chromium`。
- 调通 SPA 等待逻辑：仅等元素存在（`wait_selector`）可能命中过早；改用 `page.wait_for_function` 计数达阈值，或加大 `settle`（额外稳定秒数）。
- **更快路线**：若该站有隐藏 XHR 数据接口，直接改抓接口比解析 DOM 稳得多（用调试脚本监听 XHR 定位接口）。

### 现象 C：提取 0 条但没报挑战页
**根因**：站点改版，条目标签变了，正则失效。

**对策**：重新抓一份真实 HTML，针对新结构校正 `item_block` / `fields`；脚本会因 0 条自动跳过、保留旧 feed，不会污染订阅。

---

## 四、浏览器抓取（Playwright）前置

`fetch:"browser"` 仅在配置了浏览器源时才会触发，且依赖本机/CI 已装：
```
pip install playwright
python -m playwright install chromium
```
可选调参：`wait_selector`（内容选择器）、`settle`（稳定秒数）、`max_wait`（挑战等待上限）、`limit`（最多取几条）。

---

## 五、本机使用（备用刷新，不依赖 Actions）

- **预览**：双击 `preview.bat` → 生成并打开所有 `*.xml`。
- **推送刷新**：双击 `publish.bat` → 生成 → `git commit` → `git push`，Pages 自动更新。

> 本机执行前提是：本机 IP 受站点信任，且已 `git remote add origin <仓库URL>` 并登录凭证。
