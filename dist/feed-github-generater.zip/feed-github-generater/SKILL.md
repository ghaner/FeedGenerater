---
name: feed-github-generater
description: "This skill should be used when a user wants to turn any newest-first listing page (a website with no native RSS) into a URL-subscribable RSS 2.0 feed that is hosted on GitHub Pages and refreshed automatically by GitHub Actions. It covers scaffolding the generator repo, writing the config-driven sources.json, choosing between urllib and Playwright fetching, and surviving anti-bot challenges (Cloudflare or cdndefend). Trigger phrases include 'make an RSS feed for a site', '把某网站做成 RSS 订阅', '网址转 RSS', 'GitHub Pages RSS 生成器', or any request to subscribe to a site that lacks native RSS via a public URL."
agent_created: true
---

# Feed GitHub Generater

## Overview

把任意「按更新排序的列表页」做成可被 **URL 订阅**的 RSS 2.0 源，并用 GitHub Pages 提供公网订阅地址、用 GitHub Actions 定时重新生成。目标场景是那些**没有原生 RSS** 的站点（影视站、论坛、资源站、动态列表等），供 Distill Web Monitor、Feedly、Fluent Reader 等只接受 URL 的阅读器订阅。

本 skill 的方法论核心：

- **配置驱动**：一个仓库支持多个网址，每源生成独立 `<name>.xml`；新增网址只改 `sources.json`，零改代码。
- **零依赖生成器**：仅 Python 标准库即可运行；可选 Playwright 用于过 JS 算力挑战 / 等 SPA 渲染。
- **抗反爬韧性**：命中挑战页特征或提取 0 条时，**跳过该源、保留上一次成功的 feed**，订阅不中断——多源互不影响。
- **GitHub 托管**：Pages 出公网 URL，Actions 定时刷新，无需常驻服务器。

## When To Use

- 用户想把某个没有 RSS 的网站做成可订阅源（"把这个站做成 RSS"、"网址转 RSS"）。
- 用户已有 FeedGenerater 类项目，需要加新源、排错或重建脚手架。
- 用户遇到 Cloudflare / cdndefend 挑战页、`Just a moment...`、SPA 空壳等抓取失败。
- 用户要部署/调整 GitHub Pages 与 GitHub Actions 的定时刷新。

## Workflow

### 1. 脚手架一个新仓库

把本 skill 的模板文件复制到新仓库，形成如下结构：

```
<仓库名>/
├── .github/workflows/generate.yml   # 定时重新生成所有 *.xml（复制 assets/generate.yml）
├── src/
│   ├── generate_feed.py             # 主程序（复制 scripts/generate_feed.py）
│   └── sources.json                 # ★ 站点配置（复制 assets/sources.json.example 改名）
├── preview.bat                      # 本机预览（复制 assets/preview.bat）
├── publish.bat                      # 本机推送（复制 assets/publish.bat）
├── .gitignore                       # 复制 assets/.gitignore.example 改名
└── README.md
```

- `generate_feed.py` 约定放在 `src/`，同目录读取 `sources.json`，把 `<name>.xml` 写到仓库根目录。
- 完整 schema 见 `references/sources_schema.md`；部署与排错见 `references/setup_and_troubleshooting.md`。

### 2. 配置 sources.json（核心用法）

编辑 `src/sources.json`，在 `sources` 数组加一条：

```json
{
  "name": "mysite",
  "parser": "generic",
  "url": "https://example.com/?order=new",
  "base": "https://example.com",
  "feed_title": "我的站点 最近更新",
  "ttl": 60,
  "item_block": "<div class=\"vod\">(.*?)</div>",
  "fields": {
    "poster": {"pattern": "<img src=\"([^\"]+)\"", "group": 1, "abs": true},
    "link":   {"pattern": "href=\"([^\"]+)\"", "group": 1, "abs": true},
    "title":  {"pattern": "<h3>(.*?)</h3>", "group": 1, "strip_tags": true},
    "meta":   {"pattern": "<span>(.*?)</span>", "group": 1, "strip_tags": true}
  },
  "template": "<div><a href=\"{link}\"><img src=\"{poster}\"></a><b>{title}</b><p>{meta}</p></div>"
}
```

- `parser:"generic"` + `item_block`（一个捕获组 = 一个条目块）+ `fields`（各字段正则）适配规整站点；
  `parser:"seedog"` 是 seedog.cc 专用（逻辑写死在 `scripts/generate_feed.py` 的 `PARSERS` 里，可作新增专用解析器的范本）。
- 字段 `abs:true` 把相对链接用 `base` 补成绝对地址；`strip_tags:true` 去 HTML 标签。
- `template` 是每条 `<description>` 的 HTML 卡片，`{字段名}` 替换提取结果。
- 新增专用站点：在 `generate_feed.py` 写 `parse_xxx(html, cfg)` 并登记进 `PARSERS` 字典即可，无需改其它代码。

### 3. 选择抓取方式（fetch）

- `fetch:"http"`（默认）：`urllib` 直连，最快，适合无 JS 挑战的站点。
- `fetch:"browser"`：Playwright 无头浏览器，跑 JS 过 Cloudflare / cdndefend 算力挑战、并等 SPA 渲染完再取 HTML。
  配套参数：`wait_selector`（内容选择器）、`settle`（稳定秒数）、`max_wait`（挑战等待上限）、`limit`（最多取几条）。
  CI 需先装 `pip install playwright && python -m playwright install chromium`（已在 `generate.yml` 内置步骤）。

### 4. 本地验证

```bash
cd <仓库名>
python src/generate_feed.py          # 遍历 sources.json 所有启用源，生成根目录 *.xml
# 或双击 preview.bat 生成并打开预览
```

验证要点：每个 `<name>.xml` 良构、条目数与页面可见数一致、字段（尤其 `link`/`poster` 的绝对地址）正确。

### 5. 部署到 GitHub Pages + Actions

1. 推送仓库到 GitHub。
2. **Settings → Pages** → Source 选 `Deploy from a branch`，Branch 选 `main`、目录 `/ (root)`，保存。
3. `assets/generate.yml` 已配置每日零点（北京时间 = UTC 16:00）自动重新生成并推送；也可在 Actions 页面手动 **Run workflow** 立即刷新。
4. 订阅地址：`https://<用户>.github.io/<仓库>/<name>.xml`（name 见 sources.json）。

> 若启用 `fetch:"browser"` 的源，确保 `generate.yml` 里的 "Install Playwright" 步骤未被删除（默认保留）。

### 6. 排错（来自真实站点 seedog.cc / kkys14.com）

- **全是 `Just a moment...` / Cloudflare 挑战页**：挑战按 IP 信誉判定。优先用本机 IP 直连（个人宽带常被信任）、关掉代理（数据中心 IP 信誉更差、勾代理必败）；不行再带真实浏览器刚拿到的 `cf_clearance` Cookie 兜底（注意不是 `XLA_CI`）。详见 `references/setup_and_troubleshooting.md`。
- **SPA 拿到空壳（0 条）**：仅等元素存在可能命中过早，改用计数阈值或加大 `settle`；更快路线是直接抓 XHR 数据接口而非解析 DOM。
- **提取 0 条但非挑战页**：站点改版、标签变化，需重新校正 `item_block`/`fields`；脚本会自动跳过该源、保留旧 feed。

无论哪种失败，本生成器的设计都保证**不会用空/错误结果覆盖旧 feed**，订阅保持稳定。

## Resources

### scripts/
- `generate_feed.py` — 核心生成器（零依赖 + 可选 Playwright）。复制为项目 `src/generate_feed.py` 使用；内含 `seedog` 专用解析器与可扩展的 `PARSERS` 注册表。

### references/
- `sources_schema.md` — `sources.json` 完整字段 schema、字段子选项、`fields` 用法与多源示例。写配置前必读。
- `setup_and_troubleshooting.md` — GitHub Pages / Actions 部署步骤，以及 Cloudflare、SPA 空壳、改版失效等实战排错。

### assets/
- `sources.json.example` — 可直接改写的配置范例（含 seedog 专用源 + generic 示例源）。
- `generate.yml` — GitHub Actions 工作流（定时刷新 + 内置 Playwright 步骤 + XML 校验 + 安全提交）。
- `preview.bat` / `publish.bat` — Windows 本机一键预览 / 生成并推送脚本。
- `.gitignore.example` — 排除本地记忆与调试快照的忽略规则。
